<html>
  <head>
  <!--<link rel="stylesheet" type="text/css" href="css/bootstrap.css">-->
  </head>
  <body BACKGROUND="fotos/fondo.jpg">

        <div  id="demo">
        </div>

        <script>

              console.log( "Esto está funcionando." );

              loadXMLDoc();

              /**
              * Esta función se encarga de cargar el xml.
              *
              */
              function loadXMLDoc() 
              {
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function() 
                    {
                          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
                          {
                                console.log( "Ha cargado el xml." );
                                trabajar_apariencia(xmlhttp);
                          }
                    };
                    xmlhttp.open("GET", "comic1.xml", true);
                    xmlhttp.send();
              }

              /**
              * Una vez el xml ha sido cargado, se ejecuta la construcción de nuevo contenido.
              *
              */
              function trabajar_apariencia(xml) 
              {
                        var i;
                        var xmlDoc = xml.responseXML;
                        var table="";
                        var x = xmlDoc.getElementsByTagName("comic1");
                      
                        console.log( "Ha empezado la alteración del html." );

                        for (i = 0; i <x.length; i++) 
                        {  
                                      table += "<center><div id='" + x[i].getElementsByTagName("contenedor")[0].childNodes[0].nodeValue + "' style='border-radius:>" + x[i].getElementsByTagName("border1")[0].childNodes[0].nodeValue + "; -moz-border-radius:" + x[i].getElementsByTagName("border2")[0].childNodes[0].nodeValue + "; -webkit-border-radius:" + x[i].getElementsByTagName("border3")[0].childNodes[0].nodeValue + "; border:" + x[i].getElementsByTagName("color")[0].childNodes[0].nodeValue + "; background-color:rgba(2,1,1,0.5); background-imagen:url=fondo.jpg; width:" + x[i].getElementsByTagName("width0")[0].childNodes[0].nodeValue +";'>";
                                      table += "<center><div id='" + x[i].getElementsByTagName("contenido")[0].childNodes[0].nodeValue + "' style='float:" + x[i].getElementsByTagName("float")[0].childNodes[0].nodeValue + "; width:" + x[i].getElementsByTagName("width")[0].childNodes[0].nodeValue + "; background-image:" + x[i].getElementsByTagName("fondiv")[0].childNodes[0].nodeValue + "; height:550px;'>";
                                      table += "<center><div id='" + x[i].getElementsByTagName("principal")[0].childNodes[0].nodeValue + "' style='float:" + x[i].getElementsByTagName("float1")[0].childNodes[0].nodeValue + "; width:" + x[i].getElementsByTagName("width1")[0].childNodes[0].nodeValue + "; '><br><br>";
                                      table += "<div style='width:" + x[i].getElementsByTagName("widthmen1")[0].childNodes[0].nodeValue + "; background-color:" + x[i].getElementsByTagName("colormen1")[0].childNodes[0].nodeValue + "; height:" + x[i].getElementsByTagName("heightmen1")[0].childNodes[0].nodeValue + ";'>" + x[i].getElementsByTagName("mensaje1")[0].childNodes[0].nodeValue + "</div><br><br><br>";
                                      table += "<center><img src='" + x[i].getElementsByTagName("personaje1")[0].childNodes[0].nodeValue + "'></div>";
                                      table += "<center><div id='" + x[i].getElementsByTagName("secundario")[0].childNodes[0].nodeValue + "' style=' float:" + x[i].getElementsByTagName("float2")[0].childNodes[0].nodeValue + "; width:" + x[i].getElementsByTagName("width2")[0].childNodes[0].nodeValue + "; '><br><br>";
                                      table += "<div style='width:" + x[i].getElementsByTagName("widthmen2")[0].childNodes[0].nodeValue + "; background-color:" + x[i].getElementsByTagName("colormen2")[0].childNodes[0].nodeValue + "; height:" + x[i].getElementsByTagName("heightmen2")[0].childNodes[0].nodeValue + ";'>" + x[i].getElementsByTagName("mensaje2")[0].childNodes[0].nodeValue + "</div><br><br><br>";
                                      table += "<center><img src='" + x[i].getElementsByTagName("personaje2")[0].childNodes[0].nodeValue + "'></div></div></div></center><br><br>" ;


                                     // table += " <small>ACTOR <cite title='Nombre Apellidos'>" +  x[i].getElementsByTagName("cita")[0].childNodes[0].nodeValue +"</cite></small>";
                        }

                        document.getElementById("demo").innerHTML = table;
              }
        </script>


  </body>
</html>
